namespace PHIASPACE.CORE.Models{
    public class Role{
        public string Name { get; set; }
    }
}