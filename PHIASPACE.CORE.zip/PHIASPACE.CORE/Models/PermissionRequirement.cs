using Microsoft.AspNetCore.Authorization;

namespace PHIASPACE.CORE.Models{
    public class PermissionRequirement : IAuthorizationRequirement
    {
        public PermissionRequirement(string permission)
        {
            Permission = permission;
        }

        public string Permission { get; }
    }
}