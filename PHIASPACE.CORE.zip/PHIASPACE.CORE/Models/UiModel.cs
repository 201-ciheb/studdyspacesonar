namespace PHIASPACE.CORE.Models{
    public class UiModel{
        public List<ProjectModel> projects { get; set; }
    }
}