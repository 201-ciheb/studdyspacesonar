namespace PHIASPACE.CORE.Models{
    public class PermissionModel{
        public string Permission { get; set; }
        public int Id { get; set; }
        public string Client { get; set; }
    }
}