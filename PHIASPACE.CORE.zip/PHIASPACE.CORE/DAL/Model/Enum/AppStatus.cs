namespace PHIASPACE.CORE.DAL.Model.Enum{
    public enum AppStatus{
        Active,
        Inactive,
        Review
    }
}